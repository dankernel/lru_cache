var searchData=
[
  ['size',['size',['../structworkload.html#a5a1b5a6bbc572a36211bb56219e41d2e',1,'workload::size()'],['../structcache__mem.html#a58c6a91c40d59398a3ed18daccc448fc',1,'cache_mem::size()']]]
];
