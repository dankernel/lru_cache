var searchData=
[
  ['write',['write',['../structcache__mem.html#adb5a0315176779908235c7ed3e41ec57',1,'cache_mem']]]
];
