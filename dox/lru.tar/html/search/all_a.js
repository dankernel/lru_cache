var searchData=
[
  ['main',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['max',['max',['../structcache__mem.html#aca41dfab3073387e6c6063457a17f616',1,'cache_mem']]],
  ['mb',['MB',['../lru_8h.html#aa6b38d492364d98453284934ed7caee9',1,'lru.h']]]
];
