var searchData=
[
  ['time',['time',['../structworkload.html#a4401c89ba5cdd383f04301470e163cfd',1,'workload']]],
  ['type',['type',['../structworkload.html#aa2845ad1d10cf7ef276771aa7c038c40',1,'workload']]]
];
