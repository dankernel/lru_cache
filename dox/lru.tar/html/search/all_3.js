var searchData=
[
  ['debug_5foption',['DEBUG_OPTION',['../lru_8h.html#ae596a4581aaa87caa5cfc716730adaa1',1,'lru.h']]],
  ['del_5fcm',['del_cm',['../lru_8h.html#a23006b111470e3ef68070346a710bc65',1,'lru.h']]],
  ['disk_5fnum',['disk_num',['../structworkload.html#ac5fbfd8a1e652dc2b6e742ce685eb1fa',1,'workload']]],
  ['dk_5flist',['dk_list',['../dk__list_8h.html#ac43e6febb62e5d3998f206e4eafcad5e',1,'dk_list.h']]],
  ['dk_5flist_2eh',['dk_list.h',['../dk__list_8h.html',1,'']]]
];
