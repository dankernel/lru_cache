var searchData=
[
  ['init_5fcache_5fmem',['init_cache_mem',['../lru_8h.html#a97ee2a27cdbe15463e52c1b0606cbd1a',1,'lru.h']]],
  ['init_5fhash',['init_hash',['../hash_8h.html#acd06af48c2cda8ad19417a6eb1bbe191',1,'hash.h']]],
  ['init_5flnode',['init_lnode',['../dk__list_8h.html#a3ea33987d84e227c8398958e10a10bbd',1,'dk_list.h']]]
];
