var searchData=
[
  ['cache_5fline',['cache_line',['../structcache__line.html',1,'']]],
  ['cache_5fmem',['cache_mem',['../structcache__mem.html',1,'']]]
];
